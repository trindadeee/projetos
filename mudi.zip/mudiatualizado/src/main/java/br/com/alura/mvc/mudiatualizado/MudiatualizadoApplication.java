package br.com.alura.mvc.mudiatualizado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MudiatualizadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MudiatualizadoApplication.class, args);
	}

}

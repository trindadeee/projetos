package br.com.alura.mvc.mudiatualizado.model;

public enum StatusPedido {

	AGUARDANDO, APROVADO, ENTREGUE;
}

package br.com.alura.mvc.mudiatualizado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MudiatualizadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
